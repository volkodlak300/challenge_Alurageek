import { servicesProducts } from "../services/product-services.js";
import validaNumero from "../valida/validaNumeros.js";

const productContianer = document.querySelector("[data-product]");
const form =document.querySelector("[data-form]");
/*Crea productos*/ 
function createCard (name, price, image, id) {
    /**Se crea el elemento div del html */
    const card = document.createElement("div"); /*Creamos un div*/ 
    card.classList.add("card") /*Agregamos esa estilizacion al elemento creado*/
    
    /*Colocando variables dentro del div creado lo siguiente */
    card.innerHTML = `
     <div class="img_container">
        <img src="${image}" alt="${name}">
</div>
<div class="card_container_info">
    <p> ${name}</p>
    <div class="card_container_value">
        <p> $ ${price} </p>
        <button class="delete_button" data-id="${id}"> 
            <img src=".//imagenes/trashIcon.png" alt="Eliminar">
        </button>
    </div>
</div>
    `;
    const deleteButton = card.querySelector(".delete_button");
    deleteButton.addEventListener("click", () => {
        const productId = deleteButton.getAttribute("data-id");
        servicesProducts.deleteProduct(productId)
            .then(() => {
                card.remove();
            })
            .catch((err) => console.log(err));
    });
    /**Agrega como hijo de product container */
  productContianer.appendChild(card);  
  return card;
}
/*Para mostrar los elementos en la app*/ 
//La peticion es asincrona, para que el programa no pare
const render =async()=>{
    try{
        const listProducts = await servicesProducts.productList(); 
        console.log(listProducts);//**Vemos los productos dese la consola */
/** Ahora vamos a recorrer el arreglo y que se
muestre en nuestra app */
    listProducts.forEach(product => {
    productContianer.appendChild(
        createCard(product.name,product.price,product.image,product.id)
    )
});
    }catch(error){
        console.log(error);
    }
};
/*Sometemos el formulario al boton submit */
/*form recibe 2 parametros, el segundo es una funcion:*/
form.addEventListener("submit",(event)=>{
    event.preventDefault();
    const name = document.querySelector("[data-name]").value;
    const price = document.querySelector("[data-price]").value;
    const image = document.querySelector("[data-image]").value;
    const errorMensaje =document.getElementById("error-mensaje");
    /* console.log(name); //Si captura el nombre
    console.log(price);//Si captura el precio
    console.log(image);//Si captura el la imagen */
    if(name.length <3){
        errorMensaje.textContent = 'El nombre debe tener al menos 3 caracteres.';
        errorMensaje.style.display = 'block'; // Mostrar el mensaje de error
        console.log('El nombre debe tener al menos 3 caracteres.');
        // Ocultar el mensaje después de 5 segundos
        setTimeout(() => {
            errorMensaje.style.display = 'none';
        }, 5000);
        return; // Salir de la función si la validación falla
    } //fin valida name
    console.log(price);
    console.log(validaNumero(price));
    if (validaNumero(price) == true ){
    servicesProducts
    .createProducts(name,price,image)
    .then((res) => console.log(res))  
    .catch((err)=> console.log(err));
   
    }
    else{
        errorMensaje.textContent = 'Precio negativo o fuera del rango [1-500].';
        errorMensaje.style.display = "block"; // Mostrar el mensaje de error
        console.log("Precio negativo o fuera del rango [1-500]");
        /**Ocultando mensaje despues de 5s */
         // Ocultar el mensaje después de 5 segundos
         setTimeout(() => {
            errorMensaje.style.display = 'none';
        }, 5000);
    }  
}//fin de funcion
);

render();