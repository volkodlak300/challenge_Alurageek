const productList = () => {
    /*fetch trabaja con promesas*/ 
    return fetch("http://localhost:3000/products") /*Recibe el json de los productos*/ 
            .then((res)=> res.json())
            .catch((err)=> console.log(err));
};
const createProducts = (name,price,image)=> {
    return fetch("http://localhost:3000/products",{
        method: "POST", /*Metodo post de crear */
        headers:{
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            name,price,image,
        })
    }) /*Recibe el json de los productos*/ 
            .then((res)=> res.json())
            .catch((err)=> console.log(err));
};

/*Crear la funcion delete Products: */

/* la funcion: "productList" es exportada*/ 
export const servicesProducts ={
    productList,createProducts,
};