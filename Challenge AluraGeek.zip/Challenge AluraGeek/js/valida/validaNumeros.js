export default function validaNumero(campo) {
    // Convertimos el valor del campo a un número
    const numero = Number(campo);

    // Verificamos que el número es un entero positivo
    if (Number.isInteger(numero) && numero > 0 && numero<500) {
        return true;
    } else {
        return false;
    }
}
